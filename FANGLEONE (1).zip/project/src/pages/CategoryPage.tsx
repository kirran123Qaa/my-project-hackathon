import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { categories, trendingEvents } from '../data/mockData';
import EventCard from '../components/EventCard';

export default function CategoryPage() {
  const { id } = useParams();
  const category = categories.find(cat => cat.id === id);
  const categoryEvents = trendingEvents.filter(event => event.category === category?.name);

  if (!category) {
    return <div>Category not found</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <Link 
          to="/" 
          className="inline-flex items-center text-purple-600 hover:text-purple-700 mb-6"
        >
          <ArrowLeft size={20} className="mr-2" />
          Back to Home
        </Link>
        
        <h1 className="text-4xl font-bold text-gray-900 mb-8">
          {category.name} Events
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categoryEvents.map(event => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>

        {categoryEvents.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600">No events found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
}