import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, MapPin, Share2, Star, Ticket, CreditCard, Mail, User } from 'lucide-react';
import { trendingEvents } from '../data/mockData';

export default function EventPage() {
  const { id } = useParams();
  const event = trendingEvents.find(e => e.id === id);
  const [showBooking, setShowBooking] = useState(false);
  const [bookingData, setBookingData] = useState({
    name: '',
    email: '',
    tickets: 1,
  });

  if (!event) {
    return <div>Event not found</div>;
  }

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically handle the booking submission
    alert('Booking successful! This is a demo message.');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <Link 
          to="/" 
          className="inline-flex items-center text-purple-600 hover:text-purple-700 mb-6"
        >
          <ArrowLeft size={20} className="mr-2" />
          Back to Home
        </Link>

        <div className="bg-white rounded-xl overflow-hidden shadow-lg">
          <div className="relative h-96">
            <img
              src={event.imageUrl}
              alt={event.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-0 left-0 p-8">
              <h1 className="text-4xl font-bold text-white mb-4">{event.title}</h1>
              <div className="flex items-center space-x-4 text-white">
                <div className="flex items-center">
                  <Star size={20} className="mr-1 text-yellow-400" fill="currentColor" />
                  <span>{event.rating}</span>
                </div>
                <span>•</span>
                <span>{event.category}</span>
              </div>
            </div>
          </div>

          <div className="p-8">
            <div className="flex flex-wrap gap-8 mb-8">
              <div className="flex items-center text-gray-600">
                <Calendar size={20} className="mr-2" />
                <div>
                  <p className="font-semibold">{new Date(event.date).toLocaleDateString()}</p>
                  <p className="text-sm">{event.time}</p>
                </div>
              </div>
              <div className="flex items-center text-gray-600">
                <MapPin size={20} className="mr-2" />
                <div>
                  <p className="font-semibold">{event.venue}</p>
                  <p className="text-sm">{event.city}</p>
                </div>
              </div>
            </div>

            <p className="text-gray-600 mb-8">{event.description}</p>

            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => setShowBooking(!showBooking)}
                className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center"
              >
                <Ticket size={20} className="mr-2" />
                Get Tickets - {event.price}
              </button>
              <button className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center">
                <Share2 size={20} className="mr-2" />
                Share Event
              </button>
            </div>

            {showBooking && (
              <div className="mt-8 border-t pt-8">
                <h2 className="text-2xl font-bold mb-6">Book Your Tickets</h2>
                <form onSubmit={handleBookingSubmit} className="space-y-6 max-w-2xl">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Full Name
                    </label>
                    <div className="relative">
                      <User size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                      <input
                        type="text"
                        required
                        value={bookingData.name}
                        onChange={(e) => setBookingData({...bookingData, name: e.target.value})}
                        className="pl-10 w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="John Doe"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email
                    </label>
                    <div className="relative">
                      <Mail size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                      <input
                        type="email"
                        required
                        value={bookingData.email}
                        onChange={(e) => setBookingData({...bookingData, email: e.target.value})}
                        className="pl-10 w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="john@example.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Number of Tickets
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      required
                      value={bookingData.tickets}
                      onChange={(e) => setBookingData({...bookingData, tickets: parseInt(e.target.value)})}
                      className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Payment Details
                    </label>
                    <div className="relative">
                      <CreditCard size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                      <input
                        type="text"
                        required
                        placeholder="Card Number"
                        className="pl-10 w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <input
                        type="text"
                        required
                        placeholder="MM/YY"
                        className="p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      />
                      <input
                        type="text"
                        required
                        placeholder="CVV"
                        className="p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center"
                  >
                    <Ticket size={20} className="mr-2" />
                    Complete Booking - Total: ${parseInt(event.price.slice(1)) * bookingData.tickets}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}