import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, MapPin, Star } from 'lucide-react';
import { Event } from '../types';

interface EventCardProps {
  event: Event;
}

export default function EventCard({ event }: EventCardProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/event/${event.id}`);
  };

  return (
    <div 
      onClick={handleClick}
      className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer hover:scale-[1.02]"
    >
      <div className="relative h-48">
        <img
          src={event.imageUrl}
          alt={event.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full text-sm font-semibold">
          {event.price}
        </div>
      </div>
      <div className="p-6">
        <div className="flex items-center space-x-1 text-yellow-400 mb-2">
          <Star size={16} fill="currentColor" />
          <span className="text-sm font-medium">{event.rating}</span>
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{event.title}</h3>
        <div className="space-y-2 text-gray-600">
          <div className="flex items-center space-x-2">
            <Calendar size={16} />
            <span className="text-sm">{new Date(event.date).toLocaleDateString()}</span>
          </div>
          <div className="flex items-center space-x-2">
            <MapPin size={16} />
            <span className="text-sm">{event.venue}, {event.city}</span>
          </div>
        </div>
      </div>
    </div>
  );
}