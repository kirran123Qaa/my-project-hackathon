import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { trendingEvents } from '../data/mockData';

export default function SearchBar() {
  const [query, setQuery] = useState('');
  const [showResults, setShowResults] = useState(false);
  const navigate = useNavigate();

  const filteredEvents = trendingEvents.filter(event =>
    event.title.toLowerCase().includes(query.toLowerCase()) ||
    event.city.toLowerCase().includes(query.toLowerCase()) ||
    event.venue.toLowerCase().includes(query.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowResults(false);
  };

  const handleEventClick = (eventId: string) => {
    setQuery('');
    setShowResults(false);
    navigate(`/event/${eventId}`);
  };

  return (
    <div className="w-full max-w-3xl relative">
      <form onSubmit={handleSubmit} className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setShowResults(true);
          }}
          onFocus={() => setShowResults(true)}
          placeholder="Search for events, venues, or cities..."
          className="w-full px-6 py-4 text-lg rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent shadow-sm bg-white/90 backdrop-blur-sm"
        />
        <button
          type="submit"
          className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-gray-500 hover:text-purple-500"
        >
          <Search size={24} />
        </button>
      </form>

      {showResults && query.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-lg max-h-96 overflow-y-auto z-50">
          {filteredEvents.length > 0 ? (
            <div className="p-2">
              {filteredEvents.map((event) => (
                <button
                  key={event.id}
                  onClick={() => handleEventClick(event.id)}
                  className="w-full text-left p-4 hover:bg-purple-50 rounded-lg transition-colors"
                >
                  <h4 className="font-semibold text-gray-900">{event.title}</h4>
                  <p className="text-sm text-gray-600">{event.venue}, {event.city}</p>
                  <p className="text-sm text-purple-600">{event.date} • {event.price}</p>
                </button>
              ))}
            </div>
          ) : (
            <div className="p-4 text-center text-gray-500">
              No events found matching "{query}"
            </div>
          )}
        </div>
      )}
    </div>
  );
}