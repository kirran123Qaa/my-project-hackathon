import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import { Sparkles } from 'lucide-react';
import SearchBar from './components/SearchBar';
import CategoryList from './components/CategoryList';
import TopCities from './components/TopCities';
import EventCard from './components/EventCard';
import { trendingEvents } from './data/mockData';
import CategoryPage from './pages/CategoryPage';
import EventPage from './pages/EventPage';

function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-purple-600 via-purple-500 to-blue-500 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-10"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-purple-600/50 to-blue-500/50 backdrop-blur-sm"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Discover Amazing Events Near You
          </h2>
          <p className="text-xl text-purple-100 mb-10">
            Find and book tickets to the best events happening in your city
          </p>
          <SearchBar />
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-gradient-to-br from-purple-50 via-white to-blue-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Browse by Category</h2>
          <CategoryList />
        </div>
      </section>

      {/* Top Cities Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Popular Cities</h2>
          <TopCities />
        </div>
      </section>

      {/* Trending Events Section */}
      <section className="py-16 bg-gradient-to-br from-purple-50 via-white to-blue-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Trending Events</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {trendingEvents.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <Link to="/" className="text-3xl font-bold text-purple-600 flex items-center gap-2">
            <Sparkles />
            FestiFinder
          </Link>
        </div>
      </header>

      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/category/:id" element={<CategoryPage />} />
        <Route path="/event/:id" element={<EventPage />} />
      </Routes>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-4 flex items-center justify-center gap-2">
            <Sparkles />
            FestiFinder
          </h2>
          <p className="text-gray-400">
            © {new Date().getFullYear()} FestiFinder. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;