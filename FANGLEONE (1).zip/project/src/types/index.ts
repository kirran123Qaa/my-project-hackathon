export interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  venue: string;
  city: string;
  category: string;
  imageUrl: string;
  price: string;
  rating: number;
  description: string;
}

export type Category = {
  id: string;
  name: string;
  icon: string;
};

export type City = {
  id: string;
  name: string;
  country: string;
  imageUrl: string;
};