import React from 'react';
import { useNavigate } from 'react-router-dom';
import { categories } from '../data/mockData';
import * as LucideIcons from 'lucide-react';

export default function CategoryList() {
  const navigate = useNavigate();

  const getIcon = (iconName: string) => {
    const Icon = (LucideIcons as any)[iconName.charAt(0).toUpperCase() + iconName.slice(1)];
    return Icon ? <Icon size={24} /> : null;
  };

  const handleCategoryClick = (categoryId: string) => {
    navigate(`/category/${categoryId}`);
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => handleCategoryClick(category.id)}
          className="flex flex-col items-center justify-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-200 space-y-2 hover:bg-purple-50 hover:scale-105"
        >
          <div className="text-purple-500">{getIcon(category.icon)}</div>
          <span className="text-gray-700 font-medium">{category.name}</span>
        </button>
      ))}
    </div>
  );
}