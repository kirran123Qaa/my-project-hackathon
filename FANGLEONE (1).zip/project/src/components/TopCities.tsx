import React from 'react';
import { topCities } from '../data/mockData';

export default function TopCities() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {topCities.map((city) => (
        <div
          key={city.id}
          className="relative group overflow-hidden rounded-xl cursor-pointer"
        >
          <img
            src={city.imageUrl}
            alt={city.name}
            className="w-full h-64 object-cover transform group-hover:scale-110 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent">
            <div className="absolute bottom-0 left-0 p-6">
              <h3 className="text-white text-xl font-bold">{city.name}</h3>
              <p className="text-gray-200">{city.country}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}